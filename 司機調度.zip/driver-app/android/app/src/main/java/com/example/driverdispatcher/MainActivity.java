package com.example.driverdispatcher;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
