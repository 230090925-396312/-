document.addEventListener('DOMContentLoaded', () => {
    // ---- 1. 共享的狀態與常數 (SHARED STATE & CONSTANTS) ----
    const STORAGE_KEY = 'driver_planning_data_v7'; // 資料結構版本號
    const PREP_TIME_MINUTES = 30; // 司機執行首個任務前的準備時間
    let state = loadState();

    // ---- 2. API 與核心函式 (API & CORE FUNCTIONS) ----
    
    /**
     * 從 localStorage 載入整個應用程式的狀態。
     * @returns {object} 包含 drivers 和 tasks 陣列的應用程式狀態。
     */
    function loadState() {
        const dataJSON = localStorage.getItem(STORAGE_KEY);
        const defaultState = { drivers: [], tasks: [] };
        return dataJSON ? JSON.parse(dataJSON) : defaultState;
    }

    /**
     * 將整個應用程式的狀態儲存到 localStorage。
     */
    function saveState() {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    }

    /**
     * 在當前頁面的系統日誌中顯示一則訊息。
     * @param {string} message 要顯示的訊息。
     * @param {string} type 訊息類型 ('info', 'success', 'error')。
     */
    function logMessage(message, type = 'info') {
        const logContainer = document.getElementById('log-messages');
        if (logContainer) {
            const logEntry = document.createElement('p');
            logEntry.className = `log-${type}`;
            logEntry.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
            logContainer.prepend(logEntry);
        }
    }
    
    /**
     * 使用香港政府地理數據 API 將文字地址轉換為 WGS84 座標。
     * @param {string} address 要搜尋的地址。
     * @returns {Promise<{lon: number, lat: number}|null>} WGS84 座標 (經度, 緯度)。
     */
    async function getWGS84Coordinates(address) {
        const apiUrl = `https://geodata.gov.hk/gs/api/v1.0.0/locationSearch?q=${encodeURIComponent(address)}`;
        try {
            const response = await fetch(apiUrl);
            if (!response.ok) throw new Error(`香港地理編碼 API 請求失敗`);
            const data = await response.json();
            if (!data || data.length === 0) throw new Error(`找不到地點: "${address}"`);
            return { lon: data[0].x, lat: data[0].y }; // 回傳 WGS84 經緯度
        } catch (error) {
            logMessage(`地址轉換座標失敗: ${error.message}`, 'error');
            return null;
        }
    }

    /**
     * 呼叫「香港出行易」路線 API 來計算路程時間。
     * @param {string} originName 起點地址。
     * @param {string} destinationName 終點地址。
     * @returns {Promise<number|null>} 路程時間（分鐘）。
     */
    async function getTravelTime(originName, destinationName) {
        logMessage(`正在向「出行易」請求路程數據...`, 'info');

        // 步驟 1: 取得兩地的 WGS84 座標
        const originWGS84 = await getWGS84Coordinates(originName);
        if (!originWGS84) return null;
        const destWGS84 = await getWGS84Coordinates(destinationName);
        if (!destWGS84) return null;

        // 步驟 2: 準備 POST 請求的內容
        const routeApiUrl = 'https://tdas-api.hkemobility.gov.hk/tdas/api/route';
        const requestBody = {
            start: {
                lat: originWGS84.lat,
                long: originWGS84.lon
            },
            end: {
                lat: destWGS84.lat,
                long: destWGS84.lon
            },
            lang: "ch", // 使用中文
            type: "ST", // 最短時間 (Shortest Time)
        };

        try {
            const response = await fetch(routeApiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(requestBody)
            });

            if (!response.ok) throw new Error(`「出行易」路線 API 請求失敗`);
            
            const data = await response.json();

            if (data.status === "success" && data.routes && data.routes.length > 0) {
                const durationInMinutes = data.routes[0].total_time;
                logMessage(`路程計算成功: 約需 ${durationInMinutes} 分鐘。`, 'success');
                return durationInMinutes;
            } else {
                throw new Error(data.message || '找不到有效的路線');
            }
        } catch (error) {
            logMessage(`路程計算失敗: ${error.message}`, 'error');
            return null;
        }
    }

    /**
     * 檢查日期是否變更，並重置所有司機的每日工時。
     */
    function dailyResetCheck() {
        const todayStr = new Date().toISOString().split('T')[0];
        let changed = false;
        state.drivers.forEach(driver => {
            if (driver.lastResetDate !== todayStr) {
                if (driver.status === 'ON_DUTY') {
                    const clockInTime = new Date(driver.clockInTimeISO);
                    const midnight = new Date(todayStr);
                    driver.workedHoursToday += (midnight - clockInTime) / (3600 * 1000);
                }
                driver.workedHoursToday = 0;
                driver.status = 'OFF_DUTY';
                driver.clockInTimeISO = null;
                driver.lastResetDate = todayStr;
                changed = true;
            }
        });
        if (changed) {
            logMessage(`已為 ${todayStr} 執行每日工時重置。`, 'success');
            saveState();
        }
    }

    // ---- 3. 共享的渲染函式 (SHARED RENDERING FUNCTIONS) ----
    
    function renderDriverCards() {
        const driverContainer = document.getElementById('driver-container');
        if (!driverContainer) return;
        driverContainer.innerHTML = '<p>尚無司機。請至「任務規劃頁」新增。</p>';
        if (state.drivers.length > 0) driverContainer.innerHTML = '';
        
        state.drivers.forEach(driver => {
            let workedHours = driver.workedHoursToday || 0;
            let currentSessionHours = 0;
            if (driver.status === 'ON_DUTY' && driver.clockInTimeISO) {
                currentSessionHours = (new Date() - new Date(driver.clockInTimeISO)) / (3600 * 1000);
            }
            const totalHours = workedHours + currentSessionHours;

            let hoursDisplay = `<p>今日工時: <strong>${totalHours.toFixed(2)} 小時</strong></p>`;
            let hoursBarHTML = '';
            let isOver = false;

            if (driver.type === 'FT') {
                const limit = driver.dailyLimitHours || 10;
                const hoursPercentage = Math.min((totalHours / limit) * 100, 100);
                isOver = totalHours >= limit;
                hoursDisplay = `<p>今日工時: <strong>${totalHours.toFixed(2)} / ${limit} 小時</strong></p>`;
                hoursBarHTML = `<div class="hours-bar"><div class="hours-bar-inner" style="width: ${hoursPercentage}%;"></div></div>`;
            }

            const card = document.createElement('div');
            card.className = `driver-card status-${driver.status.toLowerCase()}`;
            if (isOver) card.classList.add('is-overtime');
            
            card.innerHTML = `
                <div class="driver-header">
                    <strong>${driver.name} (${driver.type})</strong>
                    <span class="status-badge">${driver.status === 'ON_DUTY' ? '上班中' : '下班'}</span>
                </div>
                <div class="driver-hours">
                    ${hoursDisplay}
                    ${hoursBarHTML}
                </div>
                <div class="driver-actions">
                    ${driver.status === 'OFF_DUTY'
                        ? `<button class="action-btn clock-in-btn" data-id="${driver.id}">上班</button>`
                        : `<button class="action-btn clock-out-btn" data-id="${driver.id}">下班</button>`
                    }
                </div>`;
            driverContainer.appendChild(card);
        });
    }

    function renderTasks() {
        const taskListContainer = document.getElementById('task-list-container');
        if (!taskListContainer) return;
        taskListContainer.innerHTML = '<p>尚無任何已排程任務。</p>';
        const sortedTasks = [...state.tasks].sort((a, b) => new Date(a.calculatedStartTimeISO) - new Date(b.calculatedStartTimeISO));
        if (sortedTasks.length > 0) taskListContainer.innerHTML = '';

        sortedTasks.forEach(task => {
            const driver = state.drivers.find(d => d.id === task.driverId);
            const startTime = new Date(task.calculatedStartTimeISO);
            const arrivalTime = new Date(task.desiredArrivalTimeISO);
            const descriptionHTML = task.description ? `<p style="margin: 5px 0 0; color: #555; font-size: 14px;">描述: ${task.description}</p>` : '';

            const card = document.createElement('div');
            card.className = 'task-item';
            card.innerHTML = `
                <div class="task-header">
                    <p class="task-route">${task.startLocation} → ${task.endLocation} <span>(司機: ${driver ? driver.name : 'N/A'})</span></p>
                    <button class="task-delete-btn" data-id="${task.id}">刪除</button>
                </div>
                <div class="task-timings">
                    建議出發: ${startTime.toLocaleString()} | 要求到達: ${arrivalTime.toLocaleString()}
                </div>
                ${descriptionHTML}`;
            taskListContainer.appendChild(card);
        });
    }

    async function renderSuggestions() {
        const suggestionContainer = document.getElementById('suggestion-container');
        if (!suggestionContainer) return;
        suggestionContainer.innerHTML = '<p class="log-info">正在計算明日建議...</p>';

        const now = new Date();
        const tomorrow = new Date(now);
        tomorrow.setDate(now.getDate() + 1);
        tomorrow.setHours(0, 0, 0, 0);
        const dayAfterTomorrow = new Date(tomorrow);
        dayAfterTomorrow.setDate(tomorrow.getDate() + 1);

        const tomorrowTasks = state.tasks.filter(task => {
            const taskStartTime = new Date(task.calculatedStartTimeISO);
            return taskStartTime >= tomorrow && taskStartTime < dayAfterTomorrow;
        });

        if (tomorrowTasks.length === 0) {
            suggestionContainer.innerHTML = '<p class="log-info">明日尚無任何任務。</p>';
            return;
        }

        const driverEarliestTask = {};
        tomorrowTasks.forEach(task => {
            const taskStartTime = new Date(task.calculatedStartTimeISO);
            if (!driverEarliestTask[task.driverId] || taskStartTime < new Date(driverEarliestTask[task.driverId].calculatedStartTimeISO)) {
                driverEarliestTask[task.driverId] = task;
            }
        });

        suggestionContainer.innerHTML = '';
        
        for (const driverId in driverEarliestTask) {
            const task = driverEarliestTask[driverId];
            const driver = state.drivers.find(d => d.id === task.driverId);
            if (!driver) continue;

            let suggestionText = '';
            if (driver.homeAddress) {
                const commuteMinutes = await getTravelTime(driver.homeAddress, task.startLocation);
                if (commuteMinutes !== null) {
                    const taskStartTime = new Date(task.calculatedStartTimeISO);
                    const leaveHomeTime = new Date(taskStartTime.getTime() - commuteMinutes * 60 * 1000);
                    suggestionText = `建議 <strong>${leaveHomeTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</strong> 從家裡出發, 前往 "${task.startLocation}"。`;
                } else {
                    suggestionText = `無法計算從家到任務地點的路程，請手動規劃。`;
                }
            } else {
                suggestionText = `缺少司機住址，無法提供出發建議。`;
            }

            const p = document.createElement('p');
            p.className = 'log-success';
            p.innerHTML = `<strong>${driver.name}:</strong> ${suggestionText}`;
            suggestionContainer.appendChild(p);
        }
    }

    function populateDriverSelect() {
        const driverSelect = document.getElementById('driver-select');
        if (!driverSelect) return;
        driverSelect.innerHTML = '';
        const eligibleDrivers = [];
        const ineligibleDrivers = [];

        state.drivers.forEach(driver => {
            let isEligible = true;
            if (driver.type === 'FT') {
                let workedHours = driver.workedHoursToday || 0;
                if (driver.status === 'ON_DUTY' && driver.clockInTimeISO) {
                    workedHours += (new Date() - new Date(driver.clockInTimeISO)) / (3600 * 1000);
                }
                if (workedHours >= driver.dailyLimitHours) {
                    isEligible = false;
                }
            }
            if (isEligible) {
                eligibleDrivers.push(driver);
            } else {
                ineligibleDrivers.push(driver);
            }
        });

        if (eligibleDrivers.length === 0 && ineligibleDrivers.length === 0) {
            driverSelect.innerHTML = '<option disabled>請先新增司機</option>';
            return;
        }

        eligibleDrivers.forEach(driver => {
            const option = document.createElement('option');
            option.value = driver.id;
            option.textContent = driver.name;
            driverSelect.appendChild(option);
        });

        if (ineligibleDrivers.length > 0) {
            const optgroup = document.createElement('optgroup');
            optgroup.label = "工時已滿或超時";
            ineligibleDrivers.forEach(driver => {
                const option = document.createElement('option');
                option.value = driver.id;
                option.textContent = driver.name;
                option.disabled = true;
                optgroup.appendChild(option);
            });
            driverSelect.appendChild(optgroup);
        }
    }

    // ---- 4. 頁面專屬的初始化邏輯 (PAGE-SPECIFIC INITIALIZATION) ----
    
    // -- Logic for index.html --
    if (document.getElementById('driver-container')) {
        const driverContainer = document.getElementById('driver-container');
        const exportBtn = document.getElementById('export-btn');
        const importBtn = document.getElementById('import-btn');

        driverContainer.addEventListener('click', (e) => {
            const target = e.target;
            const driverId = parseInt(target.dataset.id);
            if (!driverId) return;
            const driver = state.drivers.find(d => d.id === driverId);
            if (!driver) return;

            if (target.classList.contains('clock-in-btn')) {
                driver.status = 'ON_DUTY';
                driver.clockInTimeISO = new Date().toISOString();
                logMessage(`${driver.name} 已上班。`, 'success');
            } else if (target.classList.contains('clock-out-btn')) {
                const durationMillis = new Date() - new Date(driver.clockInTimeISO);
                driver.workedHoursToday += durationMillis / (3600 * 1000);
                driver.status = 'OFF_DUTY';
                driver.clockInTimeISO = null;
                logMessage(`${driver.name} 已下班。本次工時 ${(durationMillis / (3600 * 1000)).toFixed(2)} 小時。`, 'info');
            }
            saveState();
            renderDriverCards();
        });

        exportBtn.addEventListener('click', () => { if (state.drivers.length === 0 && state.tasks.length === 0) { logMessage('沒有數據可以匯出。', 'error'); return; } const dataStr = JSON.stringify(state, null, 2); const dataBlob = new Blob([dataStr], {type: 'application/json'}); const url = URL.createObjectURL(dataBlob); const link = document.createElement('a'); link.href = url; link.download = `drivers-tasks-backup-${new Date().toISOString().split('T')[0]}.json`; link.click(); URL.revokeObjectURL(url); logMessage('數據已成功匯出。', 'success'); });
        importBtn.addEventListener('click', () => { const input = document.createElement('input'); input.type = 'file'; input.accept = 'application/json'; input.onchange = e => { const file = e.target.files[0]; const reader = new FileReader(); reader.onload = re => { try { const content = re.target.result; const importedState = JSON.parse(content); if (importedState.drivers && importedState.tasks) { state = importedState; saveState(); dailyResetCheck(); renderDriverCards(); logMessage('數據已成功匯入。', 'success'); } else { throw new Error('檔案格式不符。'); } } catch (error) { logMessage(`匯入失敗: ${error.message}`, 'error'); } }; reader.readAsText(file); }; input.click(); });
        
        dailyResetCheck();
        renderDriverCards();
        setInterval(renderDriverCards, 5000);
        logMessage('今日儀表板已載入。', 'success');
    }

    // -- Logic for planning.html --
    if (document.getElementById('task-form')) {
        const addDriverForm = document.getElementById('add-driver-form');
        const driverTypeSelect = document.getElementById('driver-type');
        const dailyLimitGroup = document.getElementById('daily-limit-group');
        const taskForm = document.getElementById('task-form');
        const taskListContainer = document.getElementById('task-list-container');
        const calculateTimeBtn = document.getElementById('calculate-time-btn');

        calculateTimeBtn.addEventListener('click', async () => {
            const startLocation = document.getElementById('start-location').value.trim();
            const endLocation = document.getElementById('end-location').value.trim();
            const travelTimeInput = document.getElementById('travel-time');
            if (!startLocation || !endLocation) { logMessage('請先輸入起點和終點。', 'error'); return; }

            calculateTimeBtn.classList.add('is-loading');
            calculateTimeBtn.disabled = true;

            try {
                const travelMinutes = await getTravelTime(startLocation, endLocation);
                if (travelMinutes !== null) {
                    travelTimeInput.value = travelMinutes;
                }
            } finally {
                calculateTimeBtn.classList.remove('is-loading');
                calculateTimeBtn.disabled = false;
            }
        });

        driverTypeSelect.addEventListener('change', (e) => { dailyLimitGroup.style.display = e.target.value === 'FT' ? 'block' : 'none'; });

        addDriverForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const name = document.getElementById('new-driver-name').value.trim();
            const address = document.getElementById('driver-address').value.trim();
            const type = document.getElementById('driver-type').value;
            const limit = parseFloat(document.getElementById('daily-limit').value);
            if (name && address && type) {
                if (state.drivers.find(d => d.name.toLowerCase() === name.toLowerCase())) { logMessage(`司機 "${name}" 已存在。`, 'error'); return; }
                const newDriver = { id: Date.now(), name, homeAddress: address, type, dailyLimitHours: type === 'FT' ? limit : null, status: 'OFF_DUTY', clockInTimeISO: null, workedHoursToday: 0, lastResetDate: new Date().toISOString().split('T')[0] };
                state.drivers.push(newDriver);
                saveState();
                populateDriverSelect();
                addDriverForm.reset();
                logMessage(`已新增 ${type} 司機: ${name}`, 'success');
            }
        });
        
        taskForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const driverId = parseInt(document.getElementById('driver-select').value);
            const startLocation = document.getElementById('start-location').value.trim();
            const endLocation = document.getElementById('end-location').value.trim();
            const description = document.getElementById('task-description').value.trim();
            const arrivalTimeValue = document.getElementById('arrival-time').value;
            const travelMinutes = parseInt(document.getElementById('travel-time').value);

            if (!driverId || !startLocation || !endLocation || !arrivalTimeValue || isNaN(travelMinutes)) { logMessage('所有任務欄位皆為必填，請先計算路程時間。', 'error'); return; }
            
            const arrivalTime = new Date(arrivalTimeValue);
            const calculatedStartTime = new Date(arrivalTime.getTime() - travelMinutes * 60 * 1000);
            const newTask = { id: Date.now(), driverId, startLocation, endLocation, description, desiredArrivalTimeISO: arrivalTime.toISOString(), estimatedTravelMinutes: travelMinutes, calculatedStartTimeISO: calculatedStartTime.toISOString() };
            
            state.tasks.push(newTask);
            saveState();
            renderTasks();
            renderSuggestions();
            populateDriverSelect();
            taskForm.reset();
            logMessage(`已為 ${document.getElementById('driver-select').options[document.getElementById('driver-select').selectedIndex].text} 新增路線任務。`, 'success');
        });

        taskListContainer.addEventListener('click', (e) => {
            if (e.target.classList.contains('task-delete-btn')) {
                const taskId = Number(e.target.dataset.id);
                state.tasks = state.tasks.filter(task => task.id !== taskId);
                saveState();
                renderTasks();
                renderSuggestions();
            }
        });

        // 頁面載入時的初始渲染
        populateDriverSelect();
        renderTasks();
        renderSuggestions();
        logMessage('任務規劃頁已載入。', 'success');
    }
});
